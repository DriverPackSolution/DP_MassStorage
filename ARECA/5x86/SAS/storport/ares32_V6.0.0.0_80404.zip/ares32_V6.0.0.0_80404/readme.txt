******************************************************************************************
**
**        ARECA "SATA & SAS PCI" Driver Release 
**
******************************************************************************************
**        O.S   : Microsoft windows server 2K3 or later
**   FILE NAME  : ares_x86.sys
**        BY    : Erich Chen  ,mail address: erich@areca.com.tw
**   Description: Microsoft Windows STORPORT Device Driver 
**                for ARECA Co. Ltd. PCI RAID Host adapter
******************************************************************************************
** History:
**        REV#         DATE	            NAME	         DESCRIPTION
******************************************************************************************








