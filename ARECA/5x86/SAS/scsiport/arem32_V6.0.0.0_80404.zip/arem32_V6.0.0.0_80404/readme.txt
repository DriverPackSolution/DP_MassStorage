******************************************************************************************
**
**        ARECA "SATA & SAS PCI RAID" Driver Release 
**
******************************************************************************************
**        O.S   : Microsoft windows 2K XP 2K3 or later
**   FILE NAME  : arem_x86.sys
**        BY    : Erich Chen  ,mail address: erich@areca.com.tw
**   Description: Microsoft Windows SCSIPORT Device Driver 
**                for ARECA Co. Ltd. PCI RAID Host adapter
******************************************************************************************
** History:
**        REV#         DATE	            NAME	         DESCRIPTION
**     1.00.00.00     2/31/2008	       Erich Chen	     First release
******************************************************************************************








